﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Concrete_Mix_Design_Tracker
{
    struct MaterialField
    {
        public string Name;
        public string QuantityOne;
        public string QuantityTwo;
    }
    static partial class Model
    {
        const decimal UW_OF_WATER = (decimal)62.4;
        static MixDataDataContext db = new MixDataDataContext();
        const int
            MATERIALS = 0,
            PROTOTYPE = 1,
            TRIAL_BATCH = 2,
            SUBMITTAL = 3,
            MIX_DESIGN = 4;
        const int
            CEMENT = 0,
            SCM = 1,
            COARSE_AGGREGATE = 2,
            FINE_AGGREGATE = 3,
            ADMIXTURE = 4;

        /// <summary>
        /// Returns an IEnumerable list of identifiers for each tab
        /// </summary>
        /// <param name="tab">index of the tab to reference</param>
        /// <param name="filter">narrow the search with this item</param>
        /// <returns></returns>
        static public List<string> GetList(byte tab, string filter = "No Filter")
        {
            List<string> returnValues = new List<string>();
            switch (tab)
            {
                case MATERIALS:
                    if (filter != "No Filter")
                    {
                        var materialsQuery = from materialType in db.Material_Types
                                             join material in db.Materials on materialType.Material_Type_ID equals material.Material_Type_ID
                                             where materialType.Type_Name == filter
                                             select string.Format("{0:000} {1,-20} {2,10}",material.Material_ID, material.Material_Source, material.Grade);

                        foreach (var material in materialsQuery)
                        {
                            returnValues.Add(material);
                        }

                        return returnValues;
                    }
                    else
                    {
                            var materialsQuery = from material in db.Materials
                                             select string.Format("{0:000} {1,-20} {2,8}",material.Material_ID, material.Material_Source, material.Grade);


                        foreach (var material in materialsQuery)
                        {
                            returnValues.Add(material);
                        }
                        return returnValues;
                    }
                case PROTOTYPE:
                    if (filter != "No Filter")
                    {
                        var prototypeQuery = from prototype in db.Prototypes
                            where prototype.Concrete_Class == filter
                            select string.Format("{0:000} {1,20}", prototype.Prototype_ID, prototype.Prototype_Name);

                        foreach (var prototype in prototypeQuery)
                        {
                            returnValues.Add(prototype);
                        }

                        return returnValues;
                    }
                    else
                    {
                        var prototypeQuery = from prototype in db.Prototypes
                            select string.Format("{0:000} {1,20}", prototype.Prototype_ID, prototype.Prototype_Name);

                        foreach (var prototype in prototypeQuery)
                        {
                            returnValues.Add(prototype);
                        }

                        return returnValues;
                    }
                case TRIAL_BATCH:
                    if (filter != "No Filter")
                    {
                        var trialBatchQuery = from trial_batch in db.Trial_Batches
                            join prototype in db.Prototypes on trial_batch.Prototype_ID equals prototype.Prototype_ID
                            where prototype.Concrete_Class == filter
                            select string.Format("{0:00} {1,20}",trial_batch.TB_ID , trial_batch.TB_Name);
                        foreach(var trialBatch in trialBatchQuery)
                        {
                            returnValues.Add(trialBatch);
                        }

                        return returnValues;
                    }
                    else
                    {
                        var trialBatchQuery = from trial_batch in db.Trial_Batches
                            select string.Format("{0:000} {1,20}",trial_batch.TB_ID , trial_batch.TB_Name);
                        foreach (var trialBatch in trialBatchQuery)
                        {
                            returnValues.Add(trialBatch);
                        }

                        return returnValues;
                    }
                case SUBMITTAL:
                    if (filter != "No Filter")
                    {
                        var submittalQuery = from submittal in db.Submittals
                            join prototype in db.Prototypes on submittal.Prototype_ID equals prototype.Prototype_ID
                            where prototype.Concrete_Class == filter
                            select string.Format("{0:000} Owner {1,20}", submittal.Submittal_ID, submittal.Owner_Number.ToString());
                        foreach (var submittal in submittalQuery)
                        {
                            returnValues.Add(submittal);
                        }

                        return returnValues;
                    }
                    else
                    {
                        var submittalQuery = from submittal in db.Submittals
                            select string.Format("{0:000} Owner {1,20}", submittal.Submittal_ID, submittal.Owner_Number.ToString());

                        foreach (var submittal in submittalQuery)
                        {
                            returnValues.Add( submittal);
                        }

                        return returnValues;
                    }
                case MIX_DESIGN:
                    if (filter != "No Filter")
                    {
                        var mixQuery = from mix_design in db.Mix_Designs
                            join prototype in db.Prototypes on mix_design.Prototype_ID equals prototype.Prototype_ID
                            where prototype.Concrete_Class == filter
                            select string.Format("{0:000} {1,20}",mix_design.Mix_ID, mix_design.Mix_Name);

                        foreach (var mix in mixQuery)
                        {
                            returnValues.Add( mix);
                        }

                        return returnValues;
                    }
                    else
                    {
                       var mixQuery = from mix_design in db.Mix_Designs
                            select string.Format("{0:000} {1,20}",mix_design.Mix_ID, mix_design.Mix_Name);
                        foreach (var mix in mixQuery)
                        {
                            returnValues.Add(mix);
                        }
                        return returnValues;
                    }
                default:
                    return null;
            }
        }

        /// <summary>
        /// Returns an IEnumerable list of filters
        /// </summary>
        /// <param name="tab">Tab to return the filters for</param>
        /// <returns></returns>
        static public List<string> GetFilters(byte tab)
        {
            List<string> returnValue = new List<string>();
            int i;
            IEnumerable<string> Query;
            returnValue.Add("No Filter");
            switch (tab)
            {
                case MATERIALS:
                    Query = (from material in db.Materials
                             join materialType in db.Material_Types on material.Material_Type_ID equals materialType.Material_Type_ID
                         select materialType.Type_Name).Distinct();

                    foreach(var item in Query)
                    {
                        returnValue.Add(item);
                    }
                    return returnValue;

                case PROTOTYPE:
                    Query = (from prototype in db.Prototypes
                         select prototype.Concrete_Class).Distinct();

                    i = 0;
                    foreach(var item in Query)
                    {
                        returnValue.Add(item);
                    }
                    return returnValue;
                    
               case TRIAL_BATCH:
                    Query = (from trial_batch in db.Trial_Batches
                         join prototype in db.Prototypes on trial_batch.Prototype_ID equals prototype.Prototype_ID
                         select prototype.Concrete_Class).Distinct();
 
                    i = 0;
                    foreach(var item in Query)
                    {
                        returnValue.Add(item);
                    }
                    return returnValue;
               case SUBMITTAL:
                    Query = (from submittal in db.Submittals
                         join prototype in db.Prototypes on submittal.Prototype_ID equals prototype.Prototype_ID
                         select prototype.Concrete_Class).Distinct();
 
                    i = 0;
                    foreach(var item in Query)
                    {
                        returnValue.Add(item);
                    }
                    return returnValue;
               default:
                    Query = (from mix_design in db.Mix_Designs
                         join prototype in db.Prototypes on mix_design.Prototype_ID equals prototype.Prototype_ID
                         select prototype.Concrete_Class).Distinct();
 
                    i = 0;
                    foreach(var item in Query)
                    {
                        returnValue.Add(item);
                    }
                    return returnValue;
           }

        }

        /// <summary>
        /// Returns a material name based on ID
        /// </summary>
        /// <param name="ID">material_ID</param>
        /// <returns></returns>
        static public string GetMaterialName(byte ID)
         {
            return (from material in db.Materials
                    where material.Material_ID == ID
                    select material.Material_Name).First();
         }

        /// <summary>
        /// Return a material source based on ID
        /// </summary>
        /// <param name="ID">material_ID</param>
        /// <returns></returns>
        static public string GetMaterialSource(byte ID)
        {
            return (from material in db.Materials
                    where material.Material_ID == ID
                    select material.Material_Source).First();
        }
        static public string GetMaterialGrade(int ID)
        {
            return (from material in db.Materials
                    where material.Material_ID == ID
                    select material.Grade).First();
        }

        /// <summary>
        /// Return a material type based on ID
        /// </summary>
        /// <param name="ID">material_ID</param>
        /// <returns></returns>
        static public int GetMaterialType(int ID)
        {
            return (from material in db.Materials
                    where material.Material_ID == ID
                    select material.Material_Type_ID).First();
        }
        static public string GetMaterialTypeName(byte ID)
        {
            var Q =(from material in db.Materials
                    join materialType in db.Material_Types on material.Material_Type_ID equals materialType.Material_Type_ID
                    where material.Material_ID == ID
                    select materialType.Type_Name).First();
            return Q;
        }

        /// <summary>
        /// Return the relative density of a material based on ID
        /// </summary>
        /// <param name="ID">material_ID</param>
        /// <returns></returns>
        static public decimal GetMaterialRelative_Density(byte ID)
        {
            var Q = (from material in db.Materials
                    where material.Material_ID == ID
                    select material.Relative_Density).First();
            return (decimal)Q;
        }
        
        /// <summary>
        /// Return a dictionary with each property and a string of its value
        /// </summary>
        /// <param name="ID">prototype_ID</param>
        /// <returns></returns>
        static public Dictionary<string, string> GetMaterialProperties (byte ID)
        {
            Dictionary<string, string> dicReturn = new Dictionary<string, string>();
            switch (GetMaterialType(ID))
            {
                case CEMENT:
                    // Moved "grade" to main materials table but left cement table for future expansion
                        break;
                case SCM:
                    // Moved "grade" to main materials table but left scm table for future expansion
                    break;
                case COARSE_AGGREGATE:
                    var coarseAggregates =
                        db.Aggregates
                        .Join(db.Coarse_Aggregates, coarse => coarse.Aggregate_ID,
                        aggregate => aggregate.Aggregate_ID,
                        (aggregate, coarse) => new
                        {
                            Material_ID = aggregate.Material_ID,
                            Absorption = aggregate.Absorption.ToString(),
                            CA_Size = coarse.CA_Size.ToString(),
                            CA_UW = coarse.CA_UW.ToString(),
                        }).Where(aggregate => aggregate.Material_ID == ID).First();
                    dicReturn.Add(
                        "Absorption", coarseAggregates.Absorption);
                    dicReturn.Add(
                        "Size", coarseAggregates.CA_Size);
                    dicReturn.Add(
                        "Unit Weight", coarseAggregates.CA_UW);
                    break;
                case FINE_AGGREGATE:
                    var fineAggregates =
                        db.Aggregates
                        .Join(db.Fine_Aggregates, fine => fine.Aggregate_ID,
                        aggregate => aggregate.Aggregate_ID,
                        (aggregate, fine) => new
                        {
                            Material_ID = aggregate.Material_ID,
                            Absorption = aggregate.Absorption.ToString(),
                            Fineness_Modulus = fine.Fineness_Modulus.ToString(),
                        }).Where(aggregate => aggregate.Material_ID == ID).First();
                    dicReturn.Add(
                        "Absorption", fineAggregates.Absorption);
                    dicReturn.Add(
                        "Fineness Modulus", fineAggregates.Fineness_Modulus);
                    break;
                case ADMIXTURE:
                    dicReturn.Add(
                        "Minimum Dosage", db.Admixtures
                        .Where(admixture => admixture.Material_ID == ID)
                        .Select(admixture => admixture.Minimum_Dosage.ToString()).First());
                    dicReturn.Add(
                        "Maximum Dosage", db.Admixtures
                        .Where(admixture => admixture.Material_ID == ID)
                        .Select(admixture => admixture.Maximum_Dosage.ToString()).First());
                    break;

            }
            return dicReturn;
        }
        /// <summary>
        /// Returns the display name of the item
        /// </summary>
        /// <param name="ID"></param>
        /// <returns></returns>
        static public string GetName(byte tab, byte ID)
        {
            switch (tab)
            {
                case MATERIALS:
                    return db.Materials.Where(material => material.Material_ID == ID).Select(item => item.Material_Source + " " + item.Grade).First();
                case PROTOTYPE:
                    return db.Prototypes.Where(prototype => prototype.Prototype_ID == ID).Select(item => item.Prototype_Name).First();
                case TRIAL_BATCH:
                    return db.Trial_Batches.Where(trialBatch => trialBatch.TB_ID == ID).Select(item => item.TB_Name).First();
                case SUBMITTAL:
                    return db.Submittals.Where(submittal => submittal.Submittal_ID == ID).Select(item => "Owner: " + item.Owner_Number).First();
                case MIX_DESIGN:
                    return db.Mix_Designs.Where(mix => mix.Mix_ID == ID).Select(item => item.Mix_Name).First();
                default:
                    return "None shall pass.";
            }


        }

       /// <summary>
        /// Returns the total cementitious materials by weight as an int
        /// </summary>
        /// <param name="ID">ID of prototype to total</param>
        /// <returns></returns>
        static public int GetTotalCementitious (byte ID)
        {
            return
                (int)db.Cement_Proportions.Where(cement => cement.Prototype_ID == ID).Sum(item => item.Weight_of_Cement) +
                (int)db.SCM_Proportions.Where(scm => scm.Prototype_ID == ID).Sum(item => item.Weight_of_SCMs);  
        }

        /// <summary>
        /// Returns the hundred weight of cement as a decimal
        /// </summary>
        /// <param name="ID">ID of prototype to total</param>
        /// <returns></returns>
        static public decimal GetCWT (byte ID)
        {
            return
                (decimal)GetTotalCementitious(ID) / 100;
        }

        /// <summary>
        /// Return a key value pair with Water as the key and the qty as the value
        /// </summary>
        /// <param name="ID">prototype_ID</param>
        /// <returns></returns>
        static public int GetPrototypeWater (byte ID)
        {
            int materialQuery = Convert.ToInt32((from prototype in db.Prototypes
                                select prototype.Weight_of_Water).First());

            return materialQuery;
        }

        /// <summary>
        /// Returns a double representing the water/ cement ratio
        /// </summary>
        /// <param name="ID">prototype_ID</param>
        /// <returns></returns>
        static public decimal GetWaterCMRatio (byte ID)
        {
            return (decimal) ((decimal)GetPrototypeWater(ID)/(decimal)GetTotalCementitious(ID));
        }

        /// <summary>
        /// Returns a volume calculated from weight for a given material
        /// </summary>
        /// <param name="ID">Material_ID</param>
        /// <param name="weight">Weight to be converted</param>
        /// <returns>Decimal representing a volume of material</returns>
        static public decimal GetVolumeFromWeight (byte ID, int weight)
        {
            var Query = (from material in db.Materials
                        where material.Material_ID == ID
                        select material).First();

            return (decimal)weight / (UW_OF_WATER * (decimal)Query.Relative_Density);
        }

        /// <summary>
        /// Returns a weight calculated from volume for a given material
        /// </summary>
        /// <param name="ID">Material_ID</param>
        /// <param name="volume">Volume to be converted</param>
        /// <returns>A weight of material in lbs</returns>
        static public int GetWeightFromVolume (byte ID, decimal volume)
        {
            var Query = (from material in db.Materials
                         where material.Material_ID == ID
                         select material).First();
            return (int)(volume * UW_OF_WATER * Query.Relative_Density);
        }

        static public string GetMixSummary (byte ID)
        {
            string returnstring = "";
            // Build a string to summarize the mix design

            return returnstring;
        }

        static public Dictionary<string, string> GetProperties(int tab, int ID)
        {
            if (tab == MATERIALS)
            {
                int materialType = (from material in db.Materials
                                     where material.Material_ID == ID
                                     select material.Material_Type_ID).First();
                 if (materialType == CEMENT)
                    return GetCementProperties(ID);
                else if (materialType == SCM)
                    return GetSCMProperties(ID);
                else if (materialType == COARSE_AGGREGATE)
                    return GetCoarseAggregateProperties(ID);
                else if (materialType == FINE_AGGREGATE)
                    return GetFineAggregateProperties(ID);
                else if (materialType == ADMIXTURE)
                    return GetAdmixtureProperties(ID);
                else return null;           
            }
        switch (tab)
            {
                case PROTOTYPE:
                    return GetPrototypeProperties(ID);
                case TRIAL_BATCH:
                    return GetTrialBatchProperties(ID);
                case SUBMITTAL:
                    return GetSubmittalProperties(ID);
                case MIX_DESIGN:
                    return GetMixDesignProperties(ID);
                default:
                    return null;
            }
        }



        static public List<string> GetPrototypesWithoutMaterial(byte materialID, byte type)
        {
            List<string> lstReturn = new List<string>();
            IEnumerable<int> remaining;
            IEnumerable<int> exclude;

            switch (type)
            {
                case CEMENT:
                    int cementID = db.Cements.Where(cement => cement.Material_ID == materialID).Select(cement => cement.Cement_ID).First();
                    exclude = (from cementProportion in db.Cement_Proportions
                                where cementProportion.Cement_ID == cementID
                                select cementProportion.Prototype_ID).Distinct();
                    remaining = db.Prototypes.Select(prototype => prototype.Prototype_ID).Except(exclude);
                    break;
                case SCM:
                    int scmID = db.SCMs.Where(scm => scm.Material_ID == materialID).Select(scm => scm.SCM_ID).First();
                    exclude = (from scmProportion in db.SCM_Proportions
                                where scmProportion.SCM_ID == scmID
                                select scmProportion.Prototype_ID).Distinct();
                    remaining = db.Prototypes.Select(prototype => prototype.Prototype_ID).Except(exclude);
                    break;
                case COARSE_AGGREGATE:
                    int caID = (from aggregate in db.Aggregates
                                join ca in db.Coarse_Aggregates on aggregate.Aggregate_ID equals ca.Aggregate_ID
                                where aggregate.Material_ID == materialID
                                select ca.CA_ID).First();

                    exclude = (from caProportion in db.CA_Proportions
                               where caProportion.CA_ID == caID
                               select caProportion.Prototype_ID).Distinct();
                    remaining = db.Prototypes.Select(prototype => prototype.Prototype_ID).Except(exclude);

                    break;
                case FINE_AGGREGATE:
                    int fnID = (from aggregate in db.Aggregates
                                join fn in db.Fine_Aggregates on aggregate.Aggregate_ID equals fn.Aggregate_ID
                                where aggregate.Material_ID == materialID
                                select fn.FN_ID).First();

                    exclude = (from fnProportion in db.FN_Proportions
                               where fnProportion.FN_ID == fnID
                               select fnProportion.Prototype_ID).Distinct();
                    remaining = db.Prototypes.Select(prototype => prototype.Prototype_ID).Except(exclude);
                    break;
                case ADMIXTURE:
                    int admixID = db.Admixtures.Where(admix => admix.Material_ID == materialID).Select(admix => admix.Admixture_ID).First();
                    exclude = (from admixProportion in db.Admixture_Proportions
                                where admixProportion.Admixture_ID == admixID
                                select admixProportion.Prototype_ID).Distinct();
                    remaining = db.Prototypes.Select(prototype => prototype.Prototype_ID).Except(exclude);
                    break;

               default:
                    remaining = null;
                    break;
            }

            foreach(var item in remaining)
            {
                var proto = db.Prototypes.Where(prototype => prototype.Prototype_ID == item).First();
                lstReturn.Add(string.Format("{0:000} {1}", proto.Prototype_ID, proto.Prototype_Name));
            }
            return lstReturn;
        }

        static public void AddMaterialToPrototype(int prototypeID, int materialID)
        {
            int aggID;

            switch (db.Materials.Where(material => material.Material_ID == materialID).Select(material => material.Material_Type_ID).First())
            {
                case CEMENT:
                    Cement_Proportion cem = new Cement_Proportion();
                    cem.Prototype_ID = prototypeID;
                    cem.Cement_ID = db.Cements.Where(cement => cement.Material_ID == materialID).Select(cement => cement.Cement_ID).First();
                    cem.Weight_of_Cement = 0;
                    db.Cement_Proportions.InsertOnSubmit(cem);
                    break;
                case SCM:
                    SCM_Proportion scm = new SCM_Proportion();
                    scm.Prototype_ID = prototypeID;
                    scm.SCM_ID = db.SCMs.Where(sCM => sCM.Material_ID == materialID).Select(sCM => sCM.SCM_ID).First();
                    scm.Weight_of_SCMs = 0;
                    db.SCM_Proportions.InsertOnSubmit(scm);
                    break;
                case COARSE_AGGREGATE:
                    CA_Proportion ca = new CA_Proportion();
                    ca.Prototype_ID = prototypeID;
                    aggID = db.Aggregates.Where(agg => agg.Material_ID == materialID).Select(agg => agg.Aggregate_ID).First();
                    ca.CA_ID = db.Coarse_Aggregates.Where(cagg => cagg.Aggregate_ID == aggID).Select(cagg => cagg.CA_ID).First();
                    ca.Weight_of_CA = 0;
                    db.CA_Proportions.InsertOnSubmit(ca);
                    break;
                case FINE_AGGREGATE:
                    FN_Proportion fn = new FN_Proportion();
                    fn.Prototype_ID = prototypeID;
                    aggID = db.Aggregates.Where(agg => agg.Material_ID == materialID).Select(agg => agg.Aggregate_ID).First();
                    fn.FN_ID = db.Fine_Aggregates.Where(fagg => fagg.Aggregate_ID == aggID).Select(fagg => fagg.FN_ID).First();
                    fn.Weight_of_FN = 0;
                    break;
                case ADMIXTURE:
                    Admixture_Proportion admix = new Admixture_Proportion();
                    admix.Prototype_ID = prototypeID;
                    admix.Admixture_ID = db.Admixtures.Where(ad => ad.Material_ID == materialID).Select(ad => ad.Admixture_ID).First();
                    admix.Admixture_Qty = 0;
                    db.Admixture_Proportions.InsertOnSubmit(admix);
                    break;
            }
            db.SubmitChanges();

        }
    }
}
