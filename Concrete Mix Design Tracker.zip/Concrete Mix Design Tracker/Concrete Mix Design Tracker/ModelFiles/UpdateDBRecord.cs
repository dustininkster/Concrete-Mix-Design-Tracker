﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Concrete_Mix_Design_Tracker
{
    static partial class Model
    {
        /// <summary>
        /// Inserts a new record into the appropriate tables for a new material
        /// </summary>
        /// <param name="materialType">The type of material to make</param>
        /// <summary>
        /// Updates an existing Material record
        /// </summary>
        /// <param name="materialID">Material_ID</param>
        /// <param name="materialName">Material_Name</param>
        /// <param name="materialSource">Material_Source</param>
        /// <param name="relativeDensity">Relative_Density</param>
        /// <param name="materialTypeID">Material_Type_ID</param>
        static public void UpdateMaterial(
            byte materialID,
            string materialName,
            string materialSource,
            string materialGrade,
            decimal relativeDensity,
            byte materialTypeID
            )
        {
            var recordToUpdate = (from material in db.Materials
                                 where material.Material_ID == materialID
                                 select material).First();
            recordToUpdate.Material_Name = materialName;
            recordToUpdate.Material_Source = materialSource;
            recordToUpdate.Grade = materialGrade;
            recordToUpdate.Relative_Density = relativeDensity;
            recordToUpdate.Material_Type_ID = materialTypeID;

            db.SubmitChanges();
        }

        /// <summary>
        /// Updates an existing cement record
        /// </summary>
        /// <param name="materialID">Material_ID</param>
        /// <param name="cementType">Cement_Type</param>
        static public void UpdateCement(
            byte materialID,
            string cementType
            )
        {
            // This is a stub for future expansion
            db.SubmitChanges();
        }

        static public void UpdateSCM(
            byte materialID,
            string SCM_class
            )
        {
            // This is a stub for future expansion
            db.SubmitChanges();
        }

        /// <summary>
        /// Updates an existing Aggregate Record
        /// </summary>
        /// <param name="materialID"></param>
        /// <param name="aggregateGrade"></param>
        /// <param name="absorption"></param>
        static public void UpdateAggregate(
            byte materialID,
            string aggregateGrade,
            decimal absorption
            )
        {
            var recordToUpdate = (from agg in db.Aggregates
                                  where agg.Material_ID == materialID
                                  select agg).First();
            recordToUpdate.Absorption = absorption;
            db.SubmitChanges();
        }

        /// <summary>
        /// Updates an existing Coarse Aggregate Record
        /// </summary>
        /// <param name="materialID"></param>
        /// <param name="caSize"></param>
        /// <param name="caUnitWeight"></param>
        static public void UpdateCoarseAggregate(
            byte materialID,
            decimal caSize,
            decimal caUnitWeight)
        {
            int lookUpValue = (from agg in db.Aggregates
                              where agg.Material_ID == materialID
                              select agg.Aggregate_ID).First();

            var recordToUpdate = (from ca in db.Coarse_Aggregates
                                  where ca.Aggregate_ID == lookUpValue
                                  select ca).First();
            recordToUpdate.CA_Size = caSize;
            recordToUpdate.CA_UW = caUnitWeight;
            db.SubmitChanges();
        }

        /// <summary>
        /// Updates an existing Fine Aggregate Record
        /// </summary>
        /// <param name="materialID">Material_ID</param>
        /// <param name="finenessModulus">Fineness_Modulus</param>
        static public void UpdateFineAggregate(
            byte materialID,
            decimal finenessModulus
            )
        {
            int lookUpValue = (from agg in db.Aggregates
                                where agg.Material_ID == materialID
                                select agg.Aggregate_ID).First();
            var recordToUpdate = (from fn in db.Fine_Aggregates
                                  where fn.Aggregate_ID == lookUpValue
                                  select fn).First();
            recordToUpdate.Fineness_Modulus = finenessModulus;
            db.SubmitChanges();
        }

        /// <summary>
        /// Updates an existing Admixture Record
        /// </summary>
        /// <param name="materialID">Material_ID</param>
        /// <param name="minDose">Minimum_Dosage</param>
        /// <param name="maxDose">Maximum_Dosage</param>
        /// <param name="isByCWT">Is_ByCWT</param>
        static public void UpdateAdmixture(
            byte materialID,
            decimal minDose,
            decimal maxDose,
            bool isByCWT
            )
        {
            var recordToUpdate = (from admix in db.Admixtures
                                  where admix.Material_ID == materialID
                                  select admix).First();
            recordToUpdate.Minimum_Dosage = minDose;
            recordToUpdate.Maximum_Dosage = maxDose;
            db.SubmitChanges();
        }

        static public void UpdatePrototype(
            byte prototypeID,
            //TODO: naming scheme for prototypes etc need to be added to create
            string concreteClass,
            bool isAirEntrained,
            double targetAir,
            int totalCM,
            double totalCA,
            double calculatedDensity,
            int weightOfWater)
        {
            var recordToUpdate = (from prototype in db.Prototypes
                                  where prototype.Prototype_ID == prototypeID
                                  select prototype).First();
            recordToUpdate.Concrete_Class = concreteClass;
            recordToUpdate.Is_Air_Entrained = isAirEntrained;
            recordToUpdate.Target_Air = (decimal)targetAir;
            recordToUpdate.Weight_of_Water = weightOfWater;
        }

    }
}
 