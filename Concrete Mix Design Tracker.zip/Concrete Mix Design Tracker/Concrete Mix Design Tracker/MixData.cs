namespace Concrete_Mix_Design_Tracker
{
    partial class MixDataDataContext
    {
    }
}